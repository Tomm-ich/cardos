#pragma once
// ============================================================
//  CardOS - Tetris
//  A/D=links/rechts  W=roteer  S=sneller  Tab=menu
// ============================================================
#include <M5Cardputer.h>
#include "config.h"
#include "appstate.h"

#define TET_COLS   10
#define TET_ROWS   18
#define TET_CW     11
#define TET_CH     6
#define TET_OX     10
#define TET_OY     16

static uint8_t tetBoard[TET_ROWS][TET_COLS];
static int tetScore, tetLines, tetLevel;
static bool tetGameOver, tetPaused;
static unsigned long tetLastDrop;
static int tetDropSpeed; // ms

// 7 Tetrominos (rotatie 0)
static const int8_t TETROMINOS[7][4][2] = {
    {{0,0},{1,0},{0,1},{1,1}}, // O
    {{0,0},{1,0},{2,0},{3,0}}, // I
    {{0,0},{1,0},{2,0},{1,1}}, // T
    {{0,0},{1,0},{2,0},{2,1}}, // L
    {{0,0},{1,0},{2,0},{0,1}}, // J
    {{1,0},{2,0},{0,1},{1,1}}, // S
    {{0,0},{1,0},{1,1},{2,1}}, // Z
};

static const uint16_t TET_COLORS[] = {
    C_YELLOW, C_PRIMARY, C_ACCENT, 0xFD20, 0x001F, C_SUCCESS, C_ERROR
};

struct Piece { int8_t x, y, type, rot; };
static Piece curPiece, nextPiece;

void tet_newPiece(Piece& p) {
    p.type = random(0, 7);
    p.rot  = 0;
    p.x    = TET_COLS / 2 - 2;
    p.y    = 0;
}

void tet_drawCell(int c, int r, uint16_t color) {
    int px = TET_OX + c * TET_CW;
    int py = TET_OY + r * TET_CH;
    if (color == 0) {
        M5Cardputer.Display.fillRect(px, py, TET_CW - 1, TET_CH - 1, 0x1082);
    } else {
        M5Cardputer.Display.fillRect(px, py, TET_CW - 1, TET_CH - 1, color);
        M5Cardputer.Display.drawRect(px, py, TET_CW - 1, TET_CH - 1, 0xFFFF);
    }
}

void tet_getPieceCells(const Piece& p, int cells[4][2]) {
    // Simpele rotatie
    for (int i = 0; i < 4; i++) {
        int ox = TETROMINOS[p.type][i][0];
        int oy = TETROMINOS[p.type][i][1];
        for (int r = 0; r < p.rot; r++) {
            int tmp = ox; ox = oy; oy = 3 - tmp; // 90° CW
        }
        cells[i][0] = p.x + ox;
        cells[i][1] = p.y + oy;
    }
}

bool tet_valid(const Piece& p) {
    int cells[4][2];
    tet_getPieceCells(p, cells);
    for (int i = 0; i < 4; i++) {
        int c = cells[i][0], r = cells[i][1];
        if (c < 0 || c >= TET_COLS || r >= TET_ROWS) return false;
        if (r >= 0 && tetBoard[r][c]) return false;
    }
    return true;
}

void tet_drawPiece(const Piece& p, bool erase) {
    int cells[4][2];
    tet_getPieceCells(p, cells);
    for (int i = 0; i < 4; i++) {
        if (cells[i][1] >= 0)
            tet_drawCell(cells[i][0], cells[i][1], erase ? 0 : TET_COLORS[p.type]);
    }
}

void tet_lock(const Piece& p) {
    int cells[4][2];
    tet_getPieceCells(p, cells);
    for (int i = 0; i < 4; i++) {
        if (cells[i][1] >= 0)
            tetBoard[cells[i][1]][cells[i][0]] = p.type + 1;
    }
}

int tet_clearLines() {
    int cleared = 0;
    for (int r = TET_ROWS - 1; r >= 0; r--) {
        bool full = true;
        for (int c = 0; c < TET_COLS; c++) if (!tetBoard[r][c]) { full = false; break; }
        if (full) {
            cleared++;
            for (int rr = r; rr > 0; rr--)
                memcpy(tetBoard[rr], tetBoard[rr - 1], TET_COLS);
            memset(tetBoard[0], 0, TET_COLS);
            r++; // re-check this row
        }
    }
    return cleared;
}

void tet_drawBoard() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("TETRIS");
    d.drawRect(TET_OX - 1, TET_OY - 1, TET_COLS * TET_CW + 2, TET_ROWS * TET_CH + 2, C_PRIMARY);

    // Bord herteken
    for (int r = 0; r < TET_ROWS; r++)
        for (int c = 0; c < TET_COLS; c++)
            tet_drawCell(c, r, tetBoard[r][c] ? TET_COLORS[tetBoard[r][c] - 1] : 0);

    // Score paneel rechts
    d.setTextColor(C_TEXT); d.setTextSize(1);
    d.setCursor(126, 20); d.printf("Score");
    d.setTextColor(C_YELLOW);
    d.setCursor(126, 30); d.printf("%d", tetScore);
    d.setTextColor(C_TEXT);
    d.setCursor(126, 50); d.printf("Lines:%d", tetLines);
    d.setCursor(126, 62); d.printf("Lvl:%d", tetLevel);

    drawFooter("A/D=move W=rot S=drop Tab=menu");
}

void tetris_init() {
    memset(tetBoard, 0, sizeof(tetBoard));
    tetScore = 0; tetLines = 0; tetLevel = 1;
    tetGameOver = false; tetPaused = false;
    tetDropSpeed = 700;
    tet_newPiece(curPiece);
    tet_newPiece(nextPiece);
    tet_drawBoard();
    tet_drawPiece(curPiece, false);
}

void tetris_loop() {
    if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
        auto kb = M5Cardputer.Keyboard.keysState();
        if (kb.tab) { exitToLauncher(); return; }
        if (tetGameOver) { if (kb.enter) tetris_init(); return; }
        if (kb.enter) { tetPaused = !tetPaused; return; }

        if (!tetPaused) {
            Piece tmp = curPiece;
            for (auto key : kb.word) {
                if (key == 'a' || key == ';') { tmp.x--; if (tet_valid(tmp)) { tet_drawPiece(curPiece, true); curPiece = tmp; tet_drawPiece(curPiece, false); } else tmp = curPiece; }
                if (key == 'd' || key == '\'') { tmp.x++; if (tet_valid(tmp)) { tet_drawPiece(curPiece, true); curPiece = tmp; tet_drawPiece(curPiece, false); } else tmp = curPiece; }
                if (key == 'w' || key == ',') { tmp.rot = (tmp.rot + 1) % 4; if (tet_valid(tmp)) { tet_drawPiece(curPiece, true); curPiece = tmp; tet_drawPiece(curPiece, false); } else tmp = curPiece; }
                if (key == 's' || key == '.') { tetLastDrop = 0; } // force drop
            }
        }
    }

    if (tetGameOver || tetPaused) return;
    if (millis() - tetLastDrop < (unsigned long)tetDropSpeed) return;
    tetLastDrop = millis();

    Piece tmp = curPiece;
    tmp.y++;
    if (tet_valid(tmp)) {
        tet_drawPiece(curPiece, true);
        curPiece = tmp;
        tet_drawPiece(curPiece, false);
    } else {
        // Lock
        tet_lock(curPiece);
        int cleared = tet_clearLines();
        if (cleared) {
            tetLines += cleared;
            tetScore += cleared * cleared * 100 * tetLevel;
            tetLevel = tetLines / 10 + 1;
            tetDropSpeed = max(100, 700 - tetLevel * 60);
            M5Cardputer.Speaker.tone(880, 80);
        }
        tet_drawBoard();

        curPiece = nextPiece;
        tet_newPiece(nextPiece);

        if (!tet_valid(curPiece)) {
            tetGameOver = true;
            auto& d = M5Cardputer.Display;
            d.fillRoundRect(20, 50, 180, 40, 6, C_BG);
            d.drawRoundRect(20, 50, 180, 40, 6, C_ERROR);
            d.setTextColor(C_ERROR); d.setTextSize(2);
            d.setCursor(50, 57); d.print("GAME OVER");
            d.setTextSize(1); d.setTextColor(C_TEXT);
            d.setCursor(30, 78); d.printf("Score: %d  Enter=Opnieuw", tetScore);
            return;
        }
        tet_drawPiece(curPiece, false);
    }
}
