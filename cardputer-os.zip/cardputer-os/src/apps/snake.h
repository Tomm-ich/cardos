#pragma once
// ============================================================
//  CardOS - Snake Game
//  WASD of pijltjes = bewegen, Tab = terug naar launcher
// ============================================================
#include <M5Cardputer.h>
#include "config.h"
#include "appstate.h"

#define SNAKE_COLS  29
#define SNAKE_ROWS  13
#define CELL_W      7
#define CELL_H      7
#define BOARD_X     5
#define BOARD_Y     18

struct SnakePos { int x, y; };

static SnakePos snakeBody[SNAKE_COLS * SNAKE_ROWS];
static int snakeLen;
static int snakeDirX, snakeDirY;
static SnakePos food;
static int snakeScore;
static bool snakeGameOver;
static unsigned long snakeLastMove;
static int snakeSpeed = 200; // ms per stap

void snake_placeFood() {
    bool onSnake;
    do {
        onSnake = false;
        food.x = random(0, SNAKE_COLS);
        food.y = random(0, SNAKE_ROWS);
        for (int i = 0; i < snakeLen; i++) {
            if (snakeBody[i].x == food.x && snakeBody[i].y == food.y) {
                onSnake = true; break;
            }
        }
    } while (onSnake);
}

void snake_drawCell(int cx, int cy, uint16_t color) {
    int px = BOARD_X + cx * CELL_W;
    int py = BOARD_Y + cy * CELL_H;
    M5Cardputer.Display.fillRect(px, py, CELL_W - 1, CELL_H - 1, color);
}

void snake_drawBoard() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("SNAKE");
    d.drawRect(BOARD_X - 1, BOARD_Y - 1, SNAKE_COLS * CELL_W + 2, SNAKE_ROWS * CELL_H + 2, C_PRIMARY);

    // Score
    d.setTextSize(1);
    d.setTextColor(C_YELLOW);
    d.setCursor(4, 125);
    d.printf("Score: %d  Speed: %dms  Tab=Menu", snakeScore, snakeSpeed);
}

void snake_init() {
    snakeLen = 3;
    snakeBody[0] = {10, 6};
    snakeBody[1] = {9,  6};
    snakeBody[2] = {8,  6};
    snakeDirX = 1; snakeDirY = 0;
    snakeScore = 0;
    snakeGameOver = false;
    snakeSpeed = 200;
    snake_placeFood();
    snake_drawBoard();
    // Teken startslang
    for (int i = 0; i < snakeLen; i++)
        snake_drawCell(snakeBody[i].x, snakeBody[i].y, i == 0 ? C_SUCCESS : 0x07C0);
    snake_drawCell(food.x, food.y, C_ERROR);
}

void snake_gameOverScreen() {
    auto& d = M5Cardputer.Display;
    d.fillRoundRect(40, 45, 160, 50, 6, C_BG);
    d.drawRoundRect(40, 45, 160, 50, 6, C_ERROR);
    d.setTextColor(C_ERROR);
    d.setTextSize(2);
    d.setCursor(70, 52);
    d.print("GAME OVER");
    d.setTextSize(1);
    d.setTextColor(C_TEXT);
    d.setCursor(55, 75);
    d.printf("Score: %d  Enter=Opnieuw", snakeScore);
}

void snake_loop() {
    if (!M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
        // houd toets ingedrukt
    }

    if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
        auto kb = M5Cardputer.Keyboard.keysState();
        if (kb.tab) { exitToLauncher(); return; }

        if (snakeGameOver && kb.enter) {
            snake_init(); return;
        }

        for (auto key : kb.word) {
            if ((key == 'w' || key == ',') && snakeDirY != 1)  { snakeDirX = 0; snakeDirY = -1; }
            if ((key == 's' || key == '.') && snakeDirY != -1) { snakeDirX = 0; snakeDirY = 1;  }
            if ((key == 'a' || key == ';') && snakeDirX != 1)  { snakeDirX = -1; snakeDirY = 0; }
            if ((key == 'd' || key == '\'') && snakeDirX != -1){ snakeDirX = 1;  snakeDirY = 0; }
        }
    }

    if (snakeGameOver) return;

    if (millis() - snakeLastMove < (unsigned long)snakeSpeed) return;
    snakeLastMove = millis();

    // Wis staart
    snake_drawCell(snakeBody[snakeLen - 1].x, snakeBody[snakeLen - 1].y, C_BG);

    // Beweeg
    for (int i = snakeLen - 1; i > 0; i--) snakeBody[i] = snakeBody[i - 1];
    snakeBody[0].x += snakeDirX;
    snakeBody[0].y += snakeDirY;

    // Muur botsing
    if (snakeBody[0].x < 0 || snakeBody[0].x >= SNAKE_COLS ||
        snakeBody[0].y < 0 || snakeBody[0].y >= SNAKE_ROWS) {
        snakeGameOver = true;
        snake_gameOverScreen();
        return;
    }

    // Zelf botsing
    for (int i = 1; i < snakeLen; i++) {
        if (snakeBody[0].x == snakeBody[i].x && snakeBody[0].y == snakeBody[i].y) {
            snakeGameOver = true;
            snake_gameOverScreen();
            return;
        }
    }

    // Eten
    if (snakeBody[0].x == food.x && snakeBody[0].y == food.y) {
        snakeLen++;
        snakeScore += 10;
        if (snakeSpeed > 80) snakeSpeed -= 10; // sneller!
        snake_placeFood();
        snake_drawCell(food.x, food.y, C_ERROR);
        // Score update
        M5Cardputer.Display.setTextColor(C_YELLOW, C_BG);
        M5Cardputer.Display.setTextSize(1);
        M5Cardputer.Display.setCursor(4, 125);
        M5Cardputer.Display.printf("Score: %d  Speed: %dms  Tab=Menu  ", snakeScore, snakeSpeed);
        M5Cardputer.Speaker.tone(880, 50);
    }

    // Teken hoofd en 2e segment
    snake_drawCell(snakeBody[0].x, snakeBody[0].y, C_SUCCESS);
    if (snakeLen > 1) snake_drawCell(snakeBody[1].x, snakeBody[1].y, 0x07C0);
}
