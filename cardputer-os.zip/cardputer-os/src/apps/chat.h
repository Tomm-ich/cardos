#pragma once
// ============================================================
//  CardOS - ESP-NOW P2P Chat
//  Broadcast chat naar alle Cardputers in de buurt
//  Type je bericht, Enter = verzenden, Tab = menu
// ============================================================
#include <M5Cardputer.h>
#include <esp_now.h>
#include <WiFi.h>
#include "config.h"
#include "appstate.h"

#define CHAT_MAX_MSGS    8
#define CHAT_MSG_LEN     40
#define CHAT_NAME_LEN    12

struct ChatMsg {
    char sender[CHAT_NAME_LEN];
    char text[CHAT_MSG_LEN];
    bool isOwn;
};

static ChatMsg chatHistory[CHAT_MAX_MSGS];
static int chatMsgCount = 0;
static char chatInput[CHAT_MSG_LEN];
static int chatInputLen = 0;
static bool chatReady = false;

// ESP-NOW packet structuur
struct __attribute__((packed)) EspNowPacket {
    char sender[CHAT_NAME_LEN];
    char text[CHAT_MSG_LEN];
};

static uint8_t broadcastAddr[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

void chat_addMessage(const char* sender, const char* text, bool own) {
    if (chatMsgCount < CHAT_MAX_MSGS) {
        strncpy(chatHistory[chatMsgCount].sender, sender, CHAT_NAME_LEN - 1);
        strncpy(chatHistory[chatMsgCount].text, text, CHAT_MSG_LEN - 1);
        chatHistory[chatMsgCount].isOwn = own;
        chatMsgCount++;
    } else {
        // Schuif omhoog
        for (int i = 0; i < CHAT_MAX_MSGS - 1; i++) chatHistory[i] = chatHistory[i + 1];
        strncpy(chatHistory[CHAT_MAX_MSGS - 1].sender, sender, CHAT_NAME_LEN - 1);
        strncpy(chatHistory[CHAT_MAX_MSGS - 1].text, text, CHAT_MSG_LEN - 1);
        chatHistory[CHAT_MAX_MSGS - 1].isOwn = own;
    }
}

void chat_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("ESP-NOW CHAT");

    // Berichten
    int y = 18;
    for (int i = 0; i < chatMsgCount; i++) {
        bool own = chatHistory[i].isOwn;
        uint16_t nameColor = own ? C_ACCENT : C_PRIMARY;
        uint16_t textColor = own ? C_TEXT : C_DIM;

        d.setTextSize(1);
        d.setTextColor(nameColor);
        if (own) {
            d.setCursor(240 - strlen(chatHistory[i].sender) * 6 - 4, y);
        } else {
            d.setCursor(4, y);
        }
        d.print(chatHistory[i].sender);
        y += 10;

        d.setTextColor(textColor);
        if (own) {
            d.setCursor(240 - strlen(chatHistory[i].text) * 6 - 4, y);
        } else {
            d.setCursor(4, y);
        }
        d.print(chatHistory[i].text);
        y += 12;
        if (y > 108) break;
    }

    // Input box
    d.drawRect(2, 112, 236, 12, C_PRIMARY);
    d.fillRect(3, 113, 234, 10, 0x1082);
    d.setTextColor(C_TEXT);
    d.setTextSize(1);
    d.setCursor(5, 115);
    d.print(chatInput);
    // Cursor knippert
    if ((millis() / 500) % 2 == 0) {
        d.fillRect(5 + chatInputLen * 6, 115, 5, 8, C_PRIMARY);
    }

    if (!chatReady) {
        d.fillRoundRect(20, 40, 200, 30, 4, C_BG);
        d.drawRoundRect(20, 40, 200, 30, 4, C_ERROR);
        d.setTextColor(C_ERROR);
        d.setCursor(30, 48);
        d.print("WiFi/ESP-NOW niet actief");
        d.setTextColor(C_DIM);
        d.setCursor(30, 60);
        d.print("Stel WiFi in config.h in");
    }
}

void chat_onReceive(const uint8_t* mac, const uint8_t* data, int len) {
    EspNowPacket pkt;
    memcpy(&pkt, data, min(len, (int)sizeof(pkt)));
    chat_addMessage(pkt.sender, pkt.text, false);
    // Herteken scherm
    chat_drawScreen();
    M5Cardputer.Speaker.tone(1200, 60);
}

void chat_send() {
    if (chatInputLen == 0) return;
    chatInput[chatInputLen] = 0;
    chat_addMessage(CHAT_USERNAME, chatInput, true);

    if (chatReady) {
        EspNowPacket pkt;
        strncpy(pkt.sender, CHAT_USERNAME, CHAT_NAME_LEN - 1);
        strncpy(pkt.text, chatInput, CHAT_MSG_LEN - 1);
        esp_now_send(broadcastAddr, (uint8_t*)&pkt, sizeof(pkt));
    }

    memset(chatInput, 0, sizeof(chatInput));
    chatInputLen = 0;
    chat_drawScreen();
}

void chat_init() {
    chatMsgCount = 0;
    chatInputLen = 0;
    memset(chatInput, 0, sizeof(chatInput));
    chatReady = false;

    // WiFi in STA mode voor ESP-NOW
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();

    if (esp_now_init() == ESP_OK) {
        chatReady = true;
        esp_now_register_recv_cb(chat_onReceive);

        esp_now_peer_info_t peer = {};
        memcpy(peer.peer_addr, broadcastAddr, 6);
        peer.channel = ESPNOW_CHANNEL;
        peer.encrypt = false;
        esp_now_add_peer(&peer);

        chat_addMessage("SYS", "ESP-NOW actief! Stuur bericht:", false);
    } else {
        chat_addMessage("SYS", "ESP-NOW gefaald", false);
    }

    chat_drawScreen();
}

void chat_loop() {
    // Knipperende cursor
    static unsigned long lastBlink = 0;
    if (millis() - lastBlink > 500) {
        lastBlink = millis();
        auto& d = M5Cardputer.Display;
        // Update alleen input regel
        d.fillRect(3, 113, 234, 10, 0x1082);
        d.setTextColor(C_TEXT); d.setTextSize(1);
        d.setCursor(5, 115);
        d.print(chatInput);
        if ((millis() / 500) % 2 == 0)
            d.fillRect(5 + chatInputLen * 6, 115, 5, 8, C_PRIMARY);
    }

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { esp_now_deinit(); exitToLauncher(); return; }
    if (kb.enter) { chat_send(); return; }
    if (kb.del && chatInputLen > 0) {
        chatInput[--chatInputLen] = 0;
        chat_drawScreen();
        return;
    }

    for (auto key : kb.word) {
        if (key >= 32 && key < 127 && chatInputLen < CHAT_MSG_LEN - 1) {
            chatInput[chatInputLen++] = key;
            chatInput[chatInputLen] = 0;
            chat_drawScreen();
        }
    }
}
