#pragma once
// ============================================================
//  CardOS - AI Chatbot (Claude via Anthropic API)
//  Vereist WiFi verbinding en API key in config.h
//  Type vraag, Enter = verstuur, Tab = menu
// ============================================================
#include <M5Cardputer.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "config.h"
#include "appstate.h"

#define AI_MAX_MSGS   6
#define AI_MSG_LEN    80
#define AI_INPUT_LEN  100

struct AIMsg {
    char text[AI_MSG_LEN];
    bool isUser;
};

static AIMsg aiHistory[AI_MAX_MSGS];
static int aiMsgCount = 0;
static char aiInput[AI_INPUT_LEN];
static int aiInputLen = 0;
static bool aiConnected = false;
static bool aiWaiting = false;

// Scroll voor lange antwoorden
static int aiScrollOffset = 0;

void ai_addMsg(const char* text, bool isUser) {
    if (aiMsgCount < AI_MAX_MSGS) {
        strncpy(aiHistory[aiMsgCount].text, text, AI_MSG_LEN - 1);
        aiHistory[aiMsgCount].isUser = isUser;
        aiMsgCount++;
    } else {
        for (int i = 0; i < AI_MAX_MSGS - 1; i++) aiHistory[i] = aiHistory[i + 1];
        strncpy(aiHistory[AI_MAX_MSGS - 1].text, text, AI_MSG_LEN - 1);
        aiHistory[AI_MAX_MSGS - 1].isUser = isUser;
    }
}

void ai_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("AI CHAT - Claude");

    int y = 18;
    for (int i = 0; i < aiMsgCount; i++) {
        bool usr = aiHistory[i].isUser;
        d.setTextSize(1);

        // Naam label
        d.setTextColor(usr ? C_ACCENT : C_PRIMARY);
        d.setCursor(4, y);
        d.print(usr ? "Jij:" : "AI:");
        y += 10;

        // Tekst (gewrapt over meerdere regels)
        d.setTextColor(usr ? C_TEXT : C_DIM);
        char buf[AI_MSG_LEN];
        strncpy(buf, aiHistory[i].text, AI_MSG_LEN - 1);
        int len = strlen(buf);
        int charsPerLine = 38;
        for (int s = 0; s < len; s += charsPerLine) {
            char line[40] = {};
            strncpy(line, buf + s, min(charsPerLine, len - s));
            d.setCursor(4, y);
            d.print(line);
            y += 10;
            if (y > 108) break;
        }
        y += 2;
        if (y > 108) break;
    }

    if (aiWaiting) {
        d.setTextColor(C_YELLOW);
        d.setCursor(4, 100);
        d.print("Wacht op AI...");
    }

    // Input veld
    d.drawRect(2, 112, 236, 12, aiConnected ? C_PRIMARY : C_ERROR);
    d.fillRect(3, 113, 234, 10, 0x1082);
    d.setTextColor(C_TEXT); d.setTextSize(1);
    d.setCursor(5, 115);
    d.print(aiInput);
    if ((millis() / 500) % 2 == 0 && !aiWaiting)
        d.fillRect(5 + aiInputLen * 6, 115, 5, 8, C_PRIMARY);
}

void ai_connectWifi() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("AI CHAT - Verbinden...");
    d.setTextColor(C_PRIMARY); d.setTextSize(1);
    d.setCursor(10, 40);
    d.printf("WiFi: %s", WIFI_SSID);

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    int timeout = 0;
    while (WiFi.status() != WL_CONNECTED && timeout < 20) {
        delay(500);
        d.setCursor(10, 55);
        d.printf("Verbinden... %d/20", timeout);
        timeout++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        aiConnected = true;
        wifiConnected = true;
        d.setTextColor(C_SUCCESS);
        d.setCursor(10, 70);
        d.print("Verbonden!");
        delay(600);
    } else {
        aiConnected = false;
        d.setTextColor(C_ERROR);
        d.setCursor(10, 70);
        d.print("WiFi gefaald - offline modus");
        delay(1000);
    }
}

String ai_callClaude(const String& userMsg) {
    if (!aiConnected) return "Geen WiFi verbinding.";

    HTTPClient http;
    http.begin("https://api.anthropic.com/v1/messages");
    http.addHeader("Content-Type", "application/json");
    http.addHeader("x-api-key", ANTHROPIC_API_KEY);
    http.addHeader("anthropic-version", "2023-06-01");
    http.setTimeout(15000);

    // Bouw JSON body
    StaticJsonDocument<1024> doc;
    doc["model"] = ANTHROPIC_MODEL;
    doc["max_tokens"] = 200; // Klein scherm = korte antwoorden
    JsonArray msgs = doc.createNestedArray("messages");
    JsonObject msg = msgs.createNestedObject();
    msg["role"] = "user";
    msg["content"] = userMsg;

    // System prompt voor korte antwoorden
    doc["system"] = "Je bent een behulpzame AI assistent. Geef ALTIJD zeer korte antwoorden (max 2-3 zinnen) want je praat via een klein scherm. Antwoord in het Nederlands.";

    String body;
    serializeJson(doc, body);

    int code = http.POST(body);
    if (code != 200) {
        http.end();
        return "API fout: " + String(code);
    }

    String resp = http.getString();
    http.end();

    StaticJsonDocument<2048> respDoc;
    if (deserializeJson(respDoc, resp) != DeserializationError::Ok) return "JSON fout";

    const char* text = respDoc["content"][0]["text"];
    if (!text) return "Leeg antwoord";
    return String(text).substring(0, AI_MSG_LEN - 1);
}

void ai_send() {
    if (aiInputLen == 0 || aiWaiting) return;
    aiInput[aiInputLen] = 0;
    String question = String(aiInput);
    ai_addMsg(aiInput, true);
    memset(aiInput, 0, sizeof(aiInput));
    aiInputLen = 0;
    aiWaiting = true;
    ai_drawScreen();

    String answer = ai_callClaude(question);
    ai_addMsg(answer.c_str(), false);
    aiWaiting = false;
    M5Cardputer.Speaker.tone(880, 60);
    ai_drawScreen();
}

void aichat_init() {
    aiMsgCount = 0;
    aiInputLen = 0;
    aiWaiting = false;
    memset(aiInput, 0, sizeof(aiInput));

    if (WiFi.status() != WL_CONNECTED) {
        ai_connectWifi();
    } else {
        aiConnected = true;
    }

    ai_addMsg("Hoi! Ik ben Claude. Stel me een vraag!", false);
    ai_drawScreen();
}

void aichat_loop() {
    // Knipperende cursor
    static unsigned long lastBlink = 0;
    if (!aiWaiting && millis() - lastBlink > 500) {
        lastBlink = millis();
        auto& d = M5Cardputer.Display;
        d.fillRect(3, 113, 234, 10, 0x1082);
        d.setTextColor(C_TEXT); d.setTextSize(1);
        d.setCursor(5, 115);
        d.print(aiInput);
        if ((millis() / 500) % 2 == 0)
            d.fillRect(5 + aiInputLen * 6, 115, 5, 8, C_PRIMARY);
    }

    if (aiWaiting) return; // Wacht op API

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { exitToLauncher(); return; }
    if (kb.enter) { ai_send(); return; }
    if (kb.del && aiInputLen > 0) {
        aiInput[--aiInputLen] = 0;
        ai_drawScreen(); return;
    }

    for (auto key : kb.word) {
        if (key >= 32 && key < 127 && aiInputLen < AI_INPUT_LEN - 1) {
            aiInput[aiInputLen++] = key;
            aiInput[aiInputLen] = 0;
            ai_drawScreen();
        }
    }
}
