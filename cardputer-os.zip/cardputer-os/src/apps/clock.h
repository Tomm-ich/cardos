#pragma once
#include "wifiscanner.h"
