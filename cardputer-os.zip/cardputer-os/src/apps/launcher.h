#pragma once
// ============================================================
//  CardOS - Launcher (icon grid menu)
//  Navigeer met pijltjestoetsen, selecteer met Enter
// ============================================================
#include <M5Cardputer.h>
#include "config.h"
#include "appstate.h"

struct AppIcon {
    const char* name;
    const char* icon;   // 2-char emoji stijl
    uint16_t color;
    AppState app;
};

static const AppIcon APPS[] = {
    { "Snake",      "SN", C_SUCCESS,  APP_SNAKE     },
    { "Pong",       "PG", C_ACCENT,   APP_PONG      },
    { "Tetris",     "TT", C_PRIMARY,  APP_TETRIS    },
    { "Muziek",     "MP", C_YELLOW,   APP_MP3       },
    { "Chat",       "CH", C_PRIMARY,  APP_CHAT      },
    { "AI Chat",    "AI", C_ACCENT,   APP_AICHAT    },
    { "WiFi Scan",  "WF", C_SUCCESS,  APP_WIFISCAN  },
    { "IR Remote",  "IR", C_ERROR,    APP_IRREMOTE  },
    { "Klok",       "CL", C_YELLOW,   APP_CLOCK     },
    { "Notities",   "NT", C_DIM,      APP_NOTEPAD   },
    { "Systeem",    "SY", 0x8410,     APP_SYSINFO   },
};

static const int APP_COUNT_L = sizeof(APPS) / sizeof(APPS[0]);
static int selectedApp = 0;
static unsigned long lastBlink = 0;
static bool blinkState = false;

// Grid: 4 per rij, icoontje 52x34 px
#define ICON_W  52
#define ICON_H  34
#define GRID_X  4
#define GRID_Y  18
#define COLS    4

void launcher_drawIcon(int idx, bool selected) {
    auto& d = M5Cardputer.Display;
    int col = idx % COLS;
    int row = idx / COLS;
    int x = GRID_X + col * (ICON_W + 4);
    int y = GRID_Y + row * (ICON_H + 4);

    uint16_t borderColor = selected ? C_TEXT : APPS[idx].color;
    uint16_t bgColor = selected ? APPS[idx].color : 0x1082;

    d.fillRoundRect(x, y, ICON_W, ICON_H, 4, bgColor);
    d.drawRoundRect(x, y, ICON_W, ICON_H, 4, borderColor);

    // Icoon tekst
    d.setTextSize(2);
    d.setTextColor(selected ? C_BG : APPS[idx].color);
    d.setCursor(x + 10, y + 4);
    d.print(APPS[idx].icon);

    // Naam
    d.setTextSize(1);
    d.setTextColor(selected ? C_BG : C_DIM);
    int nameLen = strlen(APPS[idx].name);
    int nx = x + (ICON_W - nameLen * 6) / 2;
    d.setCursor(nx, y + ICON_H - 10);
    d.print(APPS[idx].name);
}

void launcher_draw() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("CardOS v" CARDOS_VERSION);

    for (int i = 0; i < APP_COUNT_L; i++) {
        launcher_drawIcon(i, i == selectedApp);
    }

    drawFooter("Pijlen: navigeer  Enter: open  Tab: sluit app");
}

void launcher_init() {
    launcher_draw();
}

void launcher_loop() {
    // Blink animatie voor geselecteerde app
    if (millis() - lastBlink > 500) {
        lastBlink = millis();
        blinkState = !blinkState;
        launcher_drawIcon(selectedApp, blinkState);
    }

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    bool redraw = false;

    if (kb.tab) {
        // Tab = niets, al in launcher
    }
    if (kb.enter) {
        currentApp = APPS[selectedApp].app;
        // Initialiseer de gekozen app
        switch (currentApp) {
            case APP_SNAKE:    extern void snake_init();    snake_init();    break;
            case APP_PONG:     extern void pong_init();     pong_init();     break;
            case APP_TETRIS:   extern void tetris_init();   tetris_init();   break;
            case APP_MP3:      extern void mp3_init();      mp3_init();      break;
            case APP_CHAT:     extern void chat_init();     chat_init();     break;
            case APP_AICHAT:   extern void aichat_init();   aichat_init();   break;
            case APP_WIFISCAN: extern void wifiscan_init(); wifiscan_init(); break;
            case APP_IRREMOTE: extern void ir_init();       ir_init();       break;
            case APP_CLOCK:    extern void clock_init();    clock_init();    break;
            case APP_NOTEPAD:  extern void notepad_init();  notepad_init();  break;
            case APP_SYSINFO:  extern void sysinfo_init();  sysinfo_init();  break;
            default: break;
        }
        return;
    }

    // Navigatie
    for (auto key : kb.word) {
        if (key == ';') { // Links
            if (selectedApp > 0) { selectedApp--; redraw = true; }
        } else if (key == '\'') { // Rechts
            if (selectedApp < APP_COUNT_L - 1) { selectedApp++; redraw = true; }
        } else if (key == ',') { // Omhoog
            if (selectedApp >= COLS) { selectedApp -= COLS; redraw = true; }
        } else if (key == '.') { // Omlaag
            if (selectedApp + COLS < APP_COUNT_L) { selectedApp += COLS; redraw = true; }
        }
    }

    if (redraw) launcher_draw();
}
