#pragma once
// ============================================================
//  CardOS - MP3 Speler
//  Laadt .mp3 bestanden van /music/ op SD kaart
//  A/D=vorige/volgende  Space=play/pause  +/-=volume  Tab=menu
// ============================================================
#include <M5Cardputer.h>
#include <SD.h>
#include "config.h"
#include "appstate.h"

// Eenvoudige MP3 via AudioOutputI2S + ESP8266Audio lib
// (voeg toe aan lib_deps: earlephilhower/ESP8266Audio)
// We tonen een volledig werkende UI; audio vereist de lib

#define MAX_TRACKS 50
static char mp3Tracks[MAX_TRACKS][64];
static int mp3Count = 0;
static int mp3Current = 0;
static int mp3Volume = SPEAKER_VOLUME;
static bool mp3Playing = false;
static unsigned long mp3Elapsed = 0;
static unsigned long mp3PlayStart = 0;

// Visualizer buffer
static uint8_t vizBar[20] = {0};

void mp3_scanSD() {
    mp3Count = 0;
    if (!sdAvailable) return;
    File dir = SD.open(SD_MUSIC_PATH);
    if (!dir) return;
    while (mp3Count < MAX_TRACKS) {
        File f = dir.openNextFile();
        if (!f) break;
        if (!f.isDirectory()) {
            String name = f.name();
            if (name.endsWith(".mp3") || name.endsWith(".MP3")) {
                snprintf(mp3Tracks[mp3Count], 64, "%s", f.name());
                mp3Count++;
            }
        }
        f.close();
    }
    dir.close();
}

void mp3_drawViz() {
    auto& d = M5Cardputer.Display;
    int ox = 10, oy = 95;
    for (int i = 0; i < 20; i++) {
        uint8_t h = mp3Playing ? random(2, 20) : 2;
        vizBar[i] = (vizBar[i] * 3 + h) / 4; // smooth
        d.fillRect(ox + i * 11, oy - vizBar[i], 8, vizBar[i], 
                   mp3Playing ? TET_COLORS[i % 7] : C_DIM);
        d.fillRect(ox + i * 11, oy - 20, 8, 20 - vizBar[i], C_BG);
    }
}

void mp3_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("MUZIEK SPELER");

    if (mp3Count == 0) {
        d.setTextColor(C_ERROR); d.setTextSize(1);
        d.setCursor(10, 50);
        d.print("Geen .mp3 op SD!");
        d.setCursor(10, 65);
        d.print("Maak /music/ map op SD");
        drawFooter("Tab=Menu");
        return;
    }

    // Track info
    d.setTextColor(C_PRIMARY); d.setTextSize(1);
    d.setCursor(6, 18);
    d.printf("Track %d/%d", mp3Current + 1, mp3Count);

    // Bestandsnaam (ingekort)
    char shortName[30];
    strncpy(shortName, mp3Tracks[mp3Current], 29);
    shortName[29] = 0;
    // Verwijder extensie
    for (int i = strlen(shortName); i > 0; i--) {
        if (shortName[i] == '.') { shortName[i] = 0; break; }
    }
    d.setTextColor(C_TEXT); d.setTextSize(1);
    d.setCursor(6, 30);
    d.print(shortName);

    // Progress bar
    d.drawRect(6, 46, 228, 6, C_DIM);
    if (mp3Playing) {
        unsigned long elapsed = (millis() - mp3PlayStart) / 1000;
        int prog = min((int)(elapsed * 228 / 180), 228); // assume ~3min
        d.fillRect(6, 46, prog, 6, C_PRIMARY);
    }

    // Status
    d.setTextColor(mp3Playing ? C_SUCCESS : C_ACCENT);
    d.setCursor(6, 58);
    d.printf("%s  Vol: %d/8", mp3Playing ? ">> SPEELT" : "|| PAUZE", mp3Volume);

    // Visualizer
    mp3_drawViz();

    drawFooter("A/D=track  Spc=play  +/-=vol  Tab=menu");
}

void mp3_play() {
    if (mp3Count == 0) return;
    mp3Playing = true;
    mp3PlayStart = millis();
    // In echte implementatie: start AudioGeneratorMP3
    M5Cardputer.Speaker.setVolume(mp3Volume);
    M5Cardputer.Speaker.tone(440, 100); // boot beep als placeholder
}

void mp3_pause() {
    mp3Playing = false;
    // In echte implementatie: stop/pause AudioGeneratorMP3
}

void mp3_init() {
    mp3_scanSD();
    mp3Current = 0;
    mp3Playing = false;
    mp3Volume = SPEAKER_VOLUME;
    mp3_drawScreen();
}

void mp3_loop() {
    // Visualizer updaten
    if (mp3Playing && millis() % 80 < 10) {
        mp3_drawViz();
    }

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { mp3_pause(); exitToLauncher(); return; }

    bool changed = false;
    for (auto key : kb.word) {
        if (key == ' ') {
            if (mp3Playing) mp3_pause(); else mp3_play();
            changed = true;
        }
        if (key == 'a' || key == ';') {
            mp3_pause();
            mp3Current = (mp3Current - 1 + mp3Count) % mp3Count;
            mp3_play(); changed = true;
        }
        if (key == 'd' || key == '\'') {
            mp3_pause();
            mp3Current = (mp3Current + 1) % mp3Count;
            mp3_play(); changed = true;
        }
        if (key == '+') { mp3Volume = min(8, mp3Volume + 1); M5Cardputer.Speaker.setVolume(mp3Volume); changed = true; }
        if (key == '-') { mp3Volume = max(0, mp3Volume - 1); M5Cardputer.Speaker.setVolume(mp3Volume); changed = true; }
    }
    if (changed) mp3_drawScreen();
}
