#pragma once
// irremote, clock, notepad, sysinfo zijn gedefinieerd in wifiscanner.h
#include "wifiscanner.h"
