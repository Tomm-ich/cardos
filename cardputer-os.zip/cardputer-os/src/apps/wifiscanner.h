#pragma once
// ============================================================
//  CardOS - WiFi Scanner
// ============================================================
#include <M5Cardputer.h>
#include <WiFi.h>
#include "config.h"
#include "appstate.h"

static int wifiNetworks = 0;
static int wifiSelected = 0;
static int wifiScroll = 0;

void wifiscan_draw() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("WIFI SCANNER");

    if (wifiNetworks == 0) {
        d.setTextColor(C_DIM); d.setTextSize(1);
        d.setCursor(10, 50); d.print("Scannen...");
    } else {
        d.setTextColor(C_PRIMARY); d.setTextSize(1);
        d.setCursor(4, 18);
        d.printf("%d netwerken gevonden:", wifiNetworks);

        int y = 30;
        for (int i = wifiScroll; i < min(wifiNetworks, wifiScroll + 7); i++) {
            bool sel = (i == wifiSelected);
            if (sel) d.fillRect(2, y - 1, 236, 11, 0x1082);

            // Signaal sterkte kleur
            int rssi = WiFi.RSSI(i);
            uint16_t sigColor = rssi > -60 ? C_SUCCESS : rssi > -80 ? C_YELLOW : C_ERROR;
            d.fillRect(2, y - 1, 4, 10, sigColor);

            d.setTextColor(sel ? C_TEXT : C_DIM);
            d.setCursor(10, y);
            char enc = WiFi.encryptionType(i) == WIFI_AUTH_OPEN ? ' ' : '*';
            d.printf("%c%-24s%4ddBm", enc, WiFi.SSID(i).substring(0, 24).c_str(), rssi);
            y += 12;
        }
    }
    drawFooter("Enter=Scan  W/S=scroll  Tab=menu");
}

void wifiscan_init() {
    wifiNetworks = 0;
    wifiSelected = 0;
    wifiScroll = 0;
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    wifiscan_draw();
    wifiNetworks = WiFi.scanNetworks();
    wifiscan_draw();
}

void wifiscan_loop() {
    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { exitToLauncher(); return; }
    if (kb.enter) { wifiscan_init(); return; }

    for (auto key : kb.word) {
        if ((key == 'w' || key == ',') && wifiSelected > 0) {
            wifiSelected--;
            if (wifiSelected < wifiScroll) wifiScroll--;
            wifiscan_draw();
        }
        if ((key == 's' || key == '.') && wifiSelected < wifiNetworks - 1) {
            wifiSelected++;
            if (wifiSelected >= wifiScroll + 7) wifiScroll++;
            wifiscan_draw();
        }
    }
}


// ============================================================
//  CardOS - IR Afstandsbediening
// ============================================================
#include <IRremoteESP8266.h>
#include <IRsend.h>

#define IR_PIN 44 // Cardputer-Adv IR pin
static IRsend irSend(IR_PIN);

struct IRButton { const char* label; uint32_t code; uint16_t protocol; };
static const IRButton IR_TV[] = {
    {"AAN/UIT", 0x20DF10EF, NEC},
    {"VOL +",   0x20DF40BF, NEC},
    {"VOL -",   0x20DFC03F, NEC},
    {"KANAAL+", 0x20DF00FF, NEC},
    {"KANAAL-", 0x20DF807F, NEC},
    {"MUTE",    0x20DF906F, NEC},
    {"HDMI1",   0x20DF23DC, NEC},
    {"HDMI2",   0x20DFA35C, NEC},
    {"TERUG",   0x20DF14EB, NEC},
    {"MENU",    0x20DFC23D, NEC},
    {"OK",      0x20DF22DD, NEC},
    {"OMHOOG",  0x20DF02FD, NEC},
};
static const int IR_COUNT = sizeof(IR_TV) / sizeof(IR_TV[0]);
static int irSelected = 0;

void ir_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("IR AFSTANDSBEDIENING");

    d.setTextColor(C_DIM); d.setTextSize(1);
    d.setCursor(4, 18);
    d.print("LG TV preset (NEC protocol)");

    int cols = 3, btnW = 76, btnH = 18;
    for (int i = 0; i < IR_COUNT; i++) {
        int col = i % cols;
        int row = i / cols;
        int x = 4 + col * (btnW + 2);
        int y = 28 + row * (btnH + 2);

        bool sel = (i == irSelected);
        d.fillRoundRect(x, y, btnW, btnH, 3, sel ? C_ERROR : 0x1082);
        d.drawRoundRect(x, y, btnW, btnH, 3, sel ? C_TEXT : C_ERROR);
        d.setTextColor(sel ? C_BG : C_TEXT);
        d.setTextSize(1);
        int tx = x + (btnW - strlen(IR_TV[i].label) * 6) / 2;
        d.setCursor(tx, y + 5);
        d.print(IR_TV[i].label);
    }
    drawFooter("Pijlen=kies  Enter=zend  Tab=menu");
}

void ir_init() {
    irSend.begin();
    irSelected = 0;
    ir_drawScreen();
}

void ir_loop() {
    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { exitToLauncher(); return; }

    bool redraw = false;
    if (kb.enter) {
        irSend.sendNEC(IR_TV[irSelected].code, 32);
        M5Cardputer.Speaker.tone(2000, 80);
        // Flash de knop
        auto& d = M5Cardputer.Display;
        int col = irSelected % 3, row = irSelected / 3;
        int x = 4 + col * 78, y = 28 + row * 20;
        d.fillRoundRect(x, y, 76, 18, 3, C_SUCCESS);
        delay(100);
        ir_drawScreen();
        return;
    }

    for (auto key : kb.word) {
        if ((key == 'a' || key == ';') && irSelected % 3 > 0) { irSelected--; redraw = true; }
        if ((key == 'd' || key == '\'') && irSelected % 3 < 2 && irSelected < IR_COUNT - 1) { irSelected++; redraw = true; }
        if ((key == 'w' || key == ',') && irSelected >= 3) { irSelected -= 3; redraw = true; }
        if ((key == 's' || key == '.') && irSelected + 3 < IR_COUNT) { irSelected += 3; redraw = true; }
    }
    if (redraw) ir_drawScreen();
}


// ============================================================
//  CardOS - Klok & Kalender
// ============================================================

static unsigned long clockStart;
static int clockH = 12, clockM = 0, clockS = 0;
static bool clockSetMode = false;
static int clockSetField = 0; // 0=uur 1=min

void clock_drawFace() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("KLOK");

    // Groot digitaal display
    d.setTextSize(3);
    d.setTextColor(C_PRIMARY);
    char timeBuf[10];
    snprintf(timeBuf, 10, "%02d:%02d:%02d", clockH, clockM, clockS);
    d.setCursor(18, 35);
    d.print(timeBuf);

    // IMU data (gyroscoop tilt klok)
    float ax, ay, az;
    M5Cardputer.Imu.getAccelData(&ax, &ay, &az);
    d.setTextColor(C_DIM); d.setTextSize(1);
    d.setCursor(4, 82);
    d.printf("IMU: X=%.2f Y=%.2f Z=%.2f", ax, ay, az);

    if (clockSetMode) {
        d.setTextColor(C_YELLOW);
        d.setCursor(4, 95);
        d.printf("Instellen: %s  +/-=aanpassen  Enter=klaar", clockSetField == 0 ? "UUR" : "MIN");
    } else {
        drawFooter("E=instellen  Tab=menu");
    }
}

void clock_init() {
    clockStart = millis();
    clockSetMode = false;
    clock_drawFace();
}

void clock_loop() {
    static unsigned long lastSec = 0;
    if (millis() - lastSec >= 1000) {
        lastSec = millis();
        clockS++;
        if (clockS >= 60) { clockS = 0; clockM++; }
        if (clockM >= 60) { clockM = 0; clockH++; }
        if (clockH >= 24) clockH = 0;
        clock_drawFace();
    }

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { exitToLauncher(); return; }
    if (kb.enter) { clockSetMode = !clockSetMode; clockSetField = 0; clock_drawFace(); return; }

    if (clockSetMode) {
        for (auto key : kb.word) {
            if (key == '+') { if (clockSetField == 0) clockH = (clockH + 1) % 24; else clockM = (clockM + 1) % 60; }
            if (key == '-') { if (clockSetField == 0) clockH = (clockH - 1 + 24) % 24; else clockM = (clockM - 1 + 60) % 60; }
            if (key == 't') clockSetField = !clockSetField; // toggle uur/min
        }
        clock_drawFace();
    }
}


// ============================================================
//  CardOS - Notitieblok
// ============================================================

#define NOTE_LINES  8
#define NOTE_W      38
static char noteLines[NOTE_LINES][NOTE_W + 1];
static int noteCurLine = 0, noteCurCol = 0;
static bool noteDirty = false;

void notepad_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("NOTITIES");

    for (int i = 0; i < NOTE_LINES; i++) {
        bool curLine = (i == noteCurLine);
        if (curLine) d.fillRect(2, 16 + i * 12, 236, 11, 0x1082);
        d.setTextColor(curLine ? C_TEXT : C_DIM);
        d.setTextSize(1);
        d.setCursor(4, 18 + i * 12);
        d.print(noteLines[i]);
        if (curLine) {
            if ((millis() / 500) % 2 == 0)
                d.fillRect(4 + noteCurCol * 6, 18 + i * 12, 5, 9, C_PRIMARY);
        }
    }
    drawFooter("Tab=menu  Enter=nieuwe regel  Del=wis");
}

void notepad_saveToSD() {
    if (!sdAvailable) return;
    File f = SD.open("/notes.txt", FILE_WRITE);
    if (!f) return;
    for (int i = 0; i < NOTE_LINES; i++) {
        f.println(noteLines[i]);
    }
    f.close();
}

void notepad_loadFromSD() {
    if (!sdAvailable) return;
    File f = SD.open("/notes.txt", FILE_READ);
    if (!f) return;
    for (int i = 0; i < NOTE_LINES && f.available(); i++) {
        String line = f.readStringUntil('\n');
        line.trim();
        strncpy(noteLines[i], line.c_str(), NOTE_W);
    }
    f.close();
}

void notepad_init() {
    memset(noteLines, 0, sizeof(noteLines));
    noteCurLine = 0; noteCurCol = 0;
    notepad_loadFromSD();
    notepad_drawScreen();
}

void notepad_loop() {
    static unsigned long lastBlink = 0;
    if (millis() - lastBlink > 400) {
        lastBlink = millis();
        notepad_drawScreen(); // blink cursor
    }

    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) {
        if (noteDirty) notepad_saveToSD();
        exitToLauncher(); return;
    }
    if (kb.enter) {
        if (noteCurLine < NOTE_LINES - 1) { noteCurLine++; noteCurCol = 0; }
        notepad_drawScreen(); return;
    }
    if (kb.del && noteCurCol > 0) {
        noteLines[noteCurLine][--noteCurCol] = 0;
        noteDirty = true;
        notepad_drawScreen(); return;
    }

    for (auto key : kb.word) {
        if (key >= 32 && key < 127 && noteCurCol < NOTE_W) {
            noteLines[noteCurLine][noteCurCol++] = key;
            noteLines[noteCurLine][noteCurCol] = 0;
            noteDirty = true;
            notepad_drawScreen();
        }
    }
}


// ============================================================
//  CardOS - Systeem Info
// ============================================================

void sysinfo_drawScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar("SYSTEEM INFO");

    float ax, ay, az;
    M5Cardputer.Imu.getAccelData(&ax, &ay, &az);

    struct InfoLine { const char* label; char value[32]; uint16_t color; };
    InfoLine info[] = {
        {"Apparaat",   "Cardputer-Adv",                    C_PRIMARY},
        {"Chip",       "ESP32-S3FN8 @ 240MHz",             C_TEXT},
        {"Flash",      "8MB",                               C_TEXT},
        {"Vrij RAM",   "",                                  C_SUCCESS},
        {"SD kaart",   sdAvailable ? "Aanwezig" : "Afwezig", sdAvailable ? C_SUCCESS : C_ERROR},
        {"WiFi",       "",                                   C_TEXT},
        {"Batterij",   "",                                   C_YELLOW},
        {"Accel X",    "",                                   C_ACCENT},
        {"Accel Y",    "",                                   C_ACCENT},
        {"FW versie",  CARDOS_VERSION,                       C_PRIMARY},
    };

    snprintf(info[3].value, 32, "%d KB", ESP.getFreeHeap() / 1024);
    snprintf(info[5].value, 32, "%s", WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString().c_str() : "Niet verbonden");
    snprintf(info[6].value, 32, "%d%%", M5Cardputer.Power.getBatteryLevel());
    snprintf(info[7].value, 32, "%.2f", ax);
    snprintf(info[8].value, 32, "%.2f", ay);

    for (int i = 0; i < 10; i++) {
        d.setTextColor(C_DIM); d.setTextSize(1);
        d.setCursor(4, 18 + i * 11);
        d.print(info[i].label);
        d.setTextColor(info[i].color);
        d.setCursor(100, 18 + i * 11);
        d.print(strlen(info[i].value) > 0 ? info[i].value : "-");
    }

    drawFooter("Tab=menu  Enter=ververs");
}

void sysinfo_init() {
    sysinfo_drawScreen();
}

void sysinfo_loop() {
    if (!M5Cardputer.Keyboard.isChange()) return;
    if (!M5Cardputer.Keyboard.isPressed()) return;

    auto kb = M5Cardputer.Keyboard.keysState();
    if (kb.tab) { exitToLauncher(); return; }
    if (kb.enter) { sysinfo_drawScreen(); return; }
}
