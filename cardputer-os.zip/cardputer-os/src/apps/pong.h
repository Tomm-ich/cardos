#pragma once
// ============================================================
//  CardOS - Pong (1 of 2-speler)
//  W/S = links, I/K = rechts (of AI)  Tab = menu
// ============================================================
#include <M5Cardputer.h>
#include "config.h"
#include "appstate.h"

#define PONG_W    230
#define PONG_H    105
#define PONG_OX   5
#define PONG_OY   16
#define PAD_H     20
#define PAD_W     4
#define BALL_S    4

struct Paddle { float y; int score; };
struct Ball   { float x, y, vx, vy; };

static Paddle pLeft, pRight;
static Ball pBall;
static bool pongGameOver;
static bool pongTwoPlayer;
static unsigned long pongLast;

void pong_reset() {
    pLeft.y  = PONG_H / 2 - PAD_H / 2;
    pRight.y = PONG_H / 2 - PAD_H / 2;
    pBall.x  = PONG_W / 2;
    pBall.y  = PONG_H / 2;
    pBall.vx = (random(2) ? 2.5f : -2.5f);
    pBall.vy = (random(2) ? 1.8f : -1.8f);
}

void pong_drawBoard() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);
    drawStatusBar(pongTwoPlayer ? "PONG - 2 Spelers" : "PONG - vs AI");
    d.drawRect(PONG_OX, PONG_OY, PONG_W, PONG_H, C_PRIMARY);

    // Middenlijn stippen
    for (int y = PONG_OY + 4; y < PONG_OY + PONG_H; y += 8) {
        d.fillRect(PONG_OX + PONG_W / 2 - 1, y, 2, 4, C_DIM);
    }

    // Score
    d.setTextSize(2);
    d.setTextColor(C_TEXT);
    d.setCursor(PONG_OX + PONG_W / 2 - 30, PONG_OY + 4);
    d.printf("%d", pLeft.score);
    d.setCursor(PONG_OX + PONG_W / 2 + 14, PONG_OY + 4);
    d.printf("%d", pRight.score);

    drawFooter("W/S=Links  I/K=Rechts(2P)  Tab=Menu");
}

void pong_drawObjects() {
    auto& d = M5Cardputer.Display;
    // Wis oud (heel veld)
    d.fillRect(PONG_OX + 2, PONG_OY + 2, PAD_W + 2, PONG_H - 4, C_BG);
    d.fillRect(PONG_OX + PONG_W - PAD_W - 4, PONG_OY + 2, PAD_W + 2, PONG_H - 4, C_BG);

    // Paddles
    d.fillRect(PONG_OX + 2, PONG_OY + (int)pLeft.y,  PAD_W, PAD_H, C_PRIMARY);
    d.fillRect(PONG_OX + PONG_W - PAD_W - 2, PONG_OY + (int)pRight.y, PAD_W, PAD_H, C_ACCENT);

    // Bal
    d.fillRect(PONG_OX + (int)pBall.x - BALL_S / 2,
               PONG_OY + (int)pBall.y - BALL_S / 2,
               BALL_S, BALL_S, C_YELLOW);
}

void pong_init() {
    pLeft.score = 0; pRight.score = 0;
    pongTwoPlayer = false;
    pongGameOver = false;
    pong_reset();
    pong_drawBoard();
    pong_drawObjects();
}

void pong_loop() {
    if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
        auto kb = M5Cardputer.Keyboard.keysState();
        if (kb.tab) { exitToLauncher(); return; }
        if (kb.enter && pongGameOver) { pLeft.score = 0; pRight.score = 0; pongGameOver = false; pong_reset(); pong_drawBoard(); }

        for (auto key : kb.word) {
            if (key == '2') pongTwoPlayer = !pongTwoPlayer;
            // Links paddle
            if (key == 'w' && pLeft.y > 2)             pLeft.y -= 4;
            if (key == 's' && pLeft.y < PONG_H - PAD_H - 2) pLeft.y += 4;
            // Rechts paddle (2P)
            if (pongTwoPlayer) {
                if (key == 'i' && pRight.y > 2)              pRight.y -= 4;
                if (key == 'k' && pRight.y < PONG_H - PAD_H - 2) pRight.y += 4;
            }
        }
    }

    if (pongGameOver) return;
    if (millis() - pongLast < 30) return;
    pongLast = millis();

    // AI voor rechts als 1P
    if (!pongTwoPlayer) {
        float target = pBall.y - PAD_H / 2;
        if (pRight.y < target - 1) pRight.y += 2.5f;
        if (pRight.y > target + 1) pRight.y -= 2.5f;
        pRight.y = constrain(pRight.y, 2, PONG_H - PAD_H - 2);
    }

    pBall.x += pBall.vx;
    pBall.y += pBall.vy;

    // Top/bottom bounce
    if (pBall.y <= 2 || pBall.y >= PONG_H - 2) {
        pBall.vy *= -1;
        M5Cardputer.Speaker.tone(440, 30);
    }

    // Paddle botsing links
    if (pBall.x <= 8 && pBall.y >= pLeft.y && pBall.y <= pLeft.y + PAD_H) {
        pBall.vx = abs(pBall.vx) * 1.05f;
        pBall.vy += random(-5, 5) * 0.2f;
        M5Cardputer.Speaker.tone(660, 40);
    }

    // Paddle botsing rechts
    if (pBall.x >= PONG_W - 8 && pBall.y >= pRight.y && pBall.y <= pRight.y + PAD_H) {
        pBall.vx = -abs(pBall.vx) * 1.05f;
        pBall.vy += random(-5, 5) * 0.2f;
        M5Cardputer.Speaker.tone(660, 40);
    }

    // Punt
    if (pBall.x <= 0) { pRight.score++; pong_reset(); pong_drawBoard(); }
    if (pBall.x >= PONG_W) { pLeft.score++;  pong_reset(); pong_drawBoard(); }

    // Win check
    if (pLeft.score >= 7 || pRight.score >= 7) {
        pongGameOver = true;
        auto& d = M5Cardputer.Display;
        d.fillRoundRect(50, 45, 140, 40, 6, C_BG);
        d.drawRoundRect(50, 45, 140, 40, 6, C_YELLOW);
        d.setTextColor(C_YELLOW);
        d.setTextSize(1);
        d.setCursor(60, 52);
        d.printf("%s WINT!", pLeft.score >= 7 ? "LINKS" : "RECHTS");
        d.setCursor(60, 65);
        d.print("Enter=Opnieuw Tab=Menu");
        return;
    }

    pong_drawObjects();
}
