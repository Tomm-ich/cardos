// ============================================================
//  CardOS v1.0 - M5Stack Cardputer-Adv
//  Een volledig featured mini-OS met:
//  - Launcher met iconen
//  - Classic Games (Snake, Pong, Tetris)
//  - MP3 Speler (van SD kaart)
//  - ESP-NOW P2P Chat
//  - AI Chatbot (Claude via WiFi)
//  - WiFi Scanner
//  - IR Afstandsbediening
//  - Klok & Kalender
//  - Notitieblok
//  - Systeem info
// ============================================================

#include <Arduino.h>
#include <M5Cardputer.h>
#include <M5GFX.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <SD.h>
#include <esp_now.h>
#include "config.h"
#include "apps/launcher.h"
#include "apps/snake.h"
#include "apps/pong.h"
#include "apps/tetris.h"
#include "apps/mp3player.h"
#include "apps/chat.h"
#include "apps/aichat.h"
#include "apps/wifiscanner.h"
#include "apps/irremote.h"
#include "apps/clock.h"
#include "apps/notepad.h"
#include "apps/sysinfo.h"

// Globale staat
AppState currentApp = APP_LAUNCHER;
bool sdAvailable = false;
bool wifiConnected = false;

void setup() {
    auto cfg = M5.config();
    M5Cardputer.begin(cfg, true);

    M5Cardputer.Display.setRotation(1);
    M5Cardputer.Display.setBrightness(128);
    M5Cardputer.Speaker.setVolume(SPEAKER_VOLUME);

    // Boot scherm
    showBootScreen();

    // SD kaart init
    if (SD.begin(GPIO_NUM_12, SPI, 25000000)) {
        sdAvailable = true;
    }

    // Launcher starten
    launcher_init();
}

void loop() {
    M5Cardputer.update();

    switch (currentApp) {
        case APP_LAUNCHER:    launcher_loop();    break;
        case APP_SNAKE:       snake_loop();       break;
        case APP_PONG:        pong_loop();        break;
        case APP_TETRIS:      tetris_loop();      break;
        case APP_MP3:         mp3_loop();         break;
        case APP_CHAT:        chat_loop();        break;
        case APP_AICHAT:      aichat_loop();      break;
        case APP_WIFISCAN:    wifiscan_loop();    break;
        case APP_IRREMOTE:    ir_loop();          break;
        case APP_CLOCK:       clock_loop();       break;
        case APP_NOTEPAD:     notepad_loop();     break;
        case APP_SYSINFO:     sysinfo_loop();     break;
        default:              launcher_loop();    break;
    }
}

void showBootScreen() {
    auto& d = M5Cardputer.Display;
    d.fillScreen(C_BG);

    // Animatie: scanlines effect
    for (int y = 0; y < SCREEN_H; y += 4) {
        d.drawLine(0, y, SCREEN_W, y, 0x1082);
        delay(3);
    }

    // Logo
    d.setTextSize(2);
    d.setTextColor(C_PRIMARY);
    d.setCursor(60, 30);
    d.print("CardOS");

    d.setTextSize(1);
    d.setTextColor(C_ACCENT);
    d.setCursor(72, 52);
    d.print("v" CARDOS_VERSION);

    d.setTextColor(C_DIM);
    d.setCursor(40, 70);
    d.print("Cardputer-Adv / ESP32-S3");

    // Loading bar
    d.drawRect(30, 90, 180, 8, C_PRIMARY);
    for (int i = 0; i <= 176; i += 4) {
        d.fillRect(32, 92, i, 4, C_PRIMARY);
        delay(15);
    }

    d.setTextColor(C_SUCCESS);
    d.setCursor(80, 110);
    d.print("KLAAR!");
    delay(600);
}
