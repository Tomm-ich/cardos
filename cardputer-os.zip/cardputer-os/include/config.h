#pragma once

// ============================================================
//  CardOS - Config
//  M5Stack Cardputer-Adv
// ============================================================

// WiFi - vul je eigen gegevens in
#define WIFI_SSID       "JouwWiFiNaam"
#define WIFI_PASSWORD   "JouwWiFiWachtwoord"

// Anthropic API voor AI Chat
#define ANTHROPIC_API_KEY  "sk-ant-JOUW-API-KEY-HIER"
#define ANTHROPIC_MODEL    "claude-3-haiku-20240307"

// ESP-NOW Chat kanaal (0-13)
#define ESPNOW_CHANNEL  1
#define CHAT_USERNAME   "CardOS"

// Display
#define SCREEN_W  240
#define SCREEN_H  135

// SD kaart paden
#define SD_MUSIC_PATH   "/music"
#define SD_VIDEO_PATH   "/video"
#define SD_SAVES_PATH   "/saves"

// Audio
#define SPEAKER_VOLUME  6   // 0-8
#define SAMPLE_RATE     44100

// UI Kleuren (RGB565)
#define C_BG        0x0841   // Donker navy
#define C_PRIMARY   0x07FF   // Cyan
#define C_ACCENT    0xF81F   // Magenta
#define C_TEXT      0xFFFF   // Wit
#define C_DIM       0x7BEF   // Grijs
#define C_SUCCESS   0x07E0   // Groen
#define C_ERROR     0xF800   // Rood
#define C_YELLOW    0xFFE0   // Geel

// Versie
#define CARDOS_VERSION  "1.0.0"
#define CARDOS_NAME     "CardOS"
