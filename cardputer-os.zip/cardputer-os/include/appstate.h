#pragma once

// ============================================================
//  CardOS - Gedeelde types & AppState
// ============================================================

enum AppState {
    APP_LAUNCHER = 0,
    APP_SNAKE,
    APP_PONG,
    APP_TETRIS,
    APP_MP3,
    APP_CHAT,
    APP_AICHAT,
    APP_WIFISCAN,
    APP_IRREMOTE,
    APP_CLOCK,
    APP_NOTEPAD,
    APP_SYSINFO,
    APP_COUNT
};

extern AppState currentApp;
extern bool sdAvailable;
extern bool wifiConnected;

// Helper: terug naar launcher
inline void exitToLauncher() {
    currentApp = APP_LAUNCHER;
    extern void launcher_init();
    launcher_init();
}

// Helper: kleine UI tekst
#include <M5Cardputer.h>
#include "config.h"

inline void drawStatusBar(const char* title) {
    auto& d = M5Cardputer.Display;
    d.fillRect(0, 0, 240, 14, C_PRIMARY);
    d.setTextColor(C_BG);
    d.setTextSize(1);
    d.setCursor(4, 3);
    d.print(title);
    // batterij indicatie rechts
    d.setCursor(190, 3);
    int bat = M5Cardputer.Power.getBatteryLevel();
    d.printf("BAT:%d%%", bat);
}

inline void drawFooter(const char* hint) {
    auto& d = M5Cardputer.Display;
    d.fillRect(0, 121, 240, 14, 0x2104);
    d.setTextColor(C_DIM);
    d.setTextSize(1);
    d.setCursor(4, 124);
    d.print(hint);
}
